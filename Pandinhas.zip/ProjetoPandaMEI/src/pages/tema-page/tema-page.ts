import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-tema',
  templateUrl: 'tema-page.html'
})
export class TemaPage {

  constructor(public navCtrl: NavController) {

  }

}
