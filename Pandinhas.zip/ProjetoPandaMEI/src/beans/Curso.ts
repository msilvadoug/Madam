export class Curso {
    constructor(
        public name:string,
        public updated:string,
        public category:string,
        public rating:string,
        public pageurl:string,
        public image,
        public evaluators:string
    ) {}
}